//An objectified version of the code from
//http://www.shervinemami.co.cc/faceRecognition.html
//with the aim of plugging it into an application

#include <cstdio>
#include <vector>
#include <string>
#include "cv.h"
#include "cvaux.h"
#include "highgui.h"
#include "FaceRecognitionObject.h"

const char *defaultTrainingName = "trainFaceRec.txt";
    
        
//constructor from train data file
FaceRecognitionObject::FaceRecognitionObject(int newFaceWidth, int newFaceHeight, char *filename)
{
    personNumTruthMat = 0; // array of person numbers
    //personNames;// array of person names (indexed by the person number). Added by Shervin.
    nPersons = 0; // the number of people in the training set. Added by Shervin.
    nTrainFaces = 0; // the number of training images
    nEigens = 0; // the number of eigenvalues
    pAvgTrainImage = 0; // the average image
    eigenVectArray = 0; // eigenvectors
    eigenValMat = 0; // eigenvalues
    projectedTrainFaceMat = 0; // projected training faces
    
    faceWidth = newFaceWidth;
    faceHeight = newFaceHeight;
    
    numNewFaces = 0;
    numNewPeople = 0;
    
    trained = false;
    
    trainFromFile(filename);
}//construct an object from a training dataset

FaceRecognitionObject::FaceRecognitionObject(char *trainXMLPath)
{
  personNumTruthMat = 0; // array of person numbers
  //personNames;// array of person names (indexed by the person number). Added by Shervin.
  nPersons = 0; // the number of people in the training set. Added by Shervin.
  nTrainFaces = 0; // the number of training images
  nEigens = 0; // the number of eigenvalues
  pAvgTrainImage = 0; // the average image
  eigenVectArray = 0; // eigenvectors
  eigenValMat = 0; // eigenvalues
  projectedTrainFaceMat = 0; // projected training faces

  numNewFaces = 0;
  numNewPeople = 0;
  
  loadTrainingData(trainXMLPath);
  printf("loaded training data \n");
}//construct an object from a trained output file
        
//blank constructor
FaceRecognitionObject::FaceRecognitionObject(int newFaceWidth, int newFaceHeight)
{
    personNumTruthMat = 0; // array of person numbers
    //personNames;// array of person names (indexed by the person number). Added by Shervin.
    nPersons = 0; // the number of people in the training set. Added by Shervin.
    nTrainFaces = 0; // the number of training images
    nEigens = 0; // the number of eigenvalues
    pAvgTrainImage = 0; // the average image
    eigenVectArray = 0; // eigenvectors
    eigenValMat = 0; // eigenvalues
    projectedTrainFaceMat = 0; // projected training faces
    
    trainingFilename = 0;
    numNewFaces = 0;
    numNewPeople = 0;
    
    faceWidth = newFaceWidth;
    faceHeight = newFaceHeight;
    
    trained = false;
}//blank constructor

FaceRecognitionObject::~FaceRecognitionObject()
{
  if (trainingFilename != 0)
  {
    free(trainingFilename);
    trainingFilename = 0;
  }
  
  cvReleaseImage(&pAvgTrainImage);
  cvReleaseImage(eigenVectArray);
  cvReleaseMat(&personNumTruthMat); // array of person numbers
  cvReleaseMat(&eigenValMat); // eigenvalues
  cvReleaseMat(&projectedTrainFaceMat); // projected training faces
  cvReleaseMat(&trainPersonNumMat);
}


bool FaceRecognitionObject::getTrained()
{
  return trained;
}//getTrained()

int FaceRecognitionObject::getFaceWidth()
{
  return faceWidth;
}

int FaceRecognitionObject::getFaceHeight()
{
  return faceHeight;
}

/*******************************************************************************
********************************************************************************
********************************************************************************
*******************************************************************************/


// Train from the data in the given text file, and store the trained data into the file 'facedata.xml'.
void FaceRecognitionObject::trainFromFile(char *chFileTrain)
{
  IplImage **faceImageArray; // array of face images
	int i, offset;
	trainingFilename = (char *) malloc(256*sizeof(char));

	// load training data
	printf("Loading the training images in '%s'\n", chFileTrain);
	faceImageArray = loadFaceImageArray(chFileTrain, &nTrainFaces);
	printf("Got %d training images.\n", nTrainFaces);
	if( nTrainFaces < 2 )
	{
		fprintf(stderr,"Need 2 or more training faces\nInput file contains only %d\n", nTrainFaces);
		exit(1);
	}

	// do PCA on the training faces
	doPCA(faceImageArray);

	// project the training images onto the PCA subspace
	projectedTrainFaceMat = cvCreateMat( nTrainFaces, nEigens, CV_32FC1 );
	offset = projectedTrainFaceMat->step / sizeof(float);
	for(i=0; i<nTrainFaces; i++)
	{
		//int offset = i * nEigens;
		cvEigenDecomposite(
			faceImageArray[i],
			nEigens,
			eigenVectArray,
			0, 0,
			pAvgTrainImage,
			//projectedTrainFaceMat->data.fl + i*nEigens);
			projectedTrainFaceMat->data.fl + i*offset);
	}

  strncpy(trainingFilename,chFileTrain,256);

	// store the recognition data as an xml file
	storeTrainingData();

	cvReleaseImage(faceImageArray);
	// Save all the eigenvectors as images, so that they can be checked.
	if (saveEigenFaceImages) 
	{
		storeEigenfaceImages();
	}
	
	trained = true;
}//trainFromFile


// Do the Principal Component Analysis, finding the average image
// and the eigenfaces that represent any image in the given dataset.
void FaceRecognitionObject::doPCA(IplImage **faceImageArray)
{
	int i;
	CvTermCriteria calcLimit;
	CvSize faceImageSize;

	// set the number of eigenvalues to use
	nEigens = nTrainFaces-1;

    //printf("in doPCA()\n");

	// allocate the eigenvector images
	faceImageSize.width  = faceImageArray[0]->width;
	faceImageSize.height = faceImageArray[0]->height;
	eigenVectArray = (IplImage**)cvAlloc(sizeof(IplImage*) * nEigens);
	for(i=0; i<nEigens; i++)
		eigenVectArray[i] = cvCreateImage(faceImageSize, IPL_DEPTH_32F, 1);

	// allocate the eigenvalue array
	eigenValMat = cvCreateMat( 1, nEigens, CV_32FC1 );

	// allocate the averaged image
	pAvgTrainImage = cvCreateImage(faceImageSize, IPL_DEPTH_32F, 1);

	// set the PCA termination criterion
	calcLimit = cvTermCriteria( CV_TERMCRIT_ITER, nEigens, 1);

    //printf("first image has depth %d, last image has depth %d\n",faceImageArray[0]->depth,faceImageArr[164]->depth);

    //printf("before cvCalcEigenObjects, numTrainFaces = %d\n",nTrainFaces);
	// compute average image, eigenvalues, and eigenvectors
	cvCalcEigenObjects(
		nTrainFaces,
		(void*)faceImageArray,
		(void*)eigenVectArray,
		CV_EIGOBJ_NO_CALLBACK,
		0,
		0,
		&calcLimit,
		pAvgTrainImage,
		eigenValMat->data.fl);

    //printf("after cvCalcEigenObjects\n");
	cvNormalize(eigenValMat, eigenValMat, 1, 0, CV_L1, 0);
}//doPCA

// Save the training data to the file 'facedata.xml'.
void FaceRecognitionObject::storeTrainingData()
{
	CvFileStorage * fileStorage;
	int i;

	// create a file-storage interface
	fileStorage = cvOpenFileStorage( "facedata.xml", 0, CV_STORAGE_WRITE );
	
	cvWriteString(fileStorage, "trainingFilename", trainingFilename,0);

	//faceWidth = cvReadIntByName(fileStorage,0,"faceWidth",0);
	//faceHeight = cvReadIntByName(fileStorage,0,"faceHeight",0);
  cvWriteInt(fileStorage,"faceWidth",faceWidth);
  cvWriteInt(fileStorage,"faceHeight",faceHeight);

	// Store the person names. Added by Shervin.
	cvWriteInt( fileStorage, "nPersons", nPersons );
	char varname[200];
	for (i=0; i<nPersons; i++) {
		sprintf( varname, "personName_%d", (i+1) );
		cvWriteString(fileStorage, varname, personNames[i].c_str(), 0);
	}
	

	// store all the data
	cvWriteInt( fileStorage, "nEigens", nEigens );
	cvWriteInt( fileStorage, "nTrainFaces", nTrainFaces );
	cvWrite(fileStorage, "trainPersonNumMat", personNumTruthMat, cvAttrList(0,0));
	cvWrite(fileStorage, "eigenValMat", eigenValMat, cvAttrList(0,0));
	cvWrite(fileStorage, "projectedTrainFaceMat", projectedTrainFaceMat, cvAttrList(0,0));
	cvWrite(fileStorage, "avgTrainImage", pAvgTrainImage, cvAttrList(0,0));
	for(i=0; i<nEigens; i++)
	{
		char varname[200];
		sprintf( varname, "eigenVect_%d", i );
		cvWrite(fileStorage, varname, eigenVectArray[i], cvAttrList(0,0));
	}

	// release the file-storage interface
	cvReleaseFileStorage( &fileStorage );
}//storeTrainingData

// Save all the eigenvectors as images, so that they can be checked.
void FaceRecognitionObject::storeEigenfaceImages()
{
	// Store the average image to a file
	printf("Saving the image of the average face as 'out_averageImage.bmp'.\n");
	cvSaveImage("out_averageImage.bmp", pAvgTrainImage);
	// Create a large image made of many eigenface images.
	// Must also convert each eigenface image to a normal 8-bit UCHAR image instead of a 32-bit float image.
	printf("Saving the %d eigenvector images as 'out_eigenfaces.bmp'\n", nEigens);
	if (nEigens > 0) {
		// Put all the eigenfaces next to each other.
		int COLUMNS = 8;	// Put upto 8 images on a row.
		int nCols = min(nEigens, COLUMNS);
		int nRows = 1 + (nEigens / COLUMNS);	// Put the rest on new rows.
		int w = eigenVectArray[0]->width;
		int h = eigenVectArray[0]->height;
		CvSize size;
		size = cvSize(nCols * w, nRows * h);
		IplImage *bigImage = cvCreateImage(size, IPL_DEPTH_8U, 1);	// 8-bit Greyscale UCHAR image
		for (int i=0; i<nEigens; i++) {
			// Get the eigenface image.
			IplImage *byteImage = convertFloatImageToUcharImage(eigenVectArray[i]);
			// Paste it into the correct position.
			int x = w * (i % COLUMNS);
			int y = h * (i / COLUMNS);
			CvRect ROI = cvRect(x, y, w, h);
			cvSetImageROI(bigImage, ROI);
			cvCopyImage(byteImage, bigImage);
			cvResetImageROI(bigImage);
			cvReleaseImage(&byteImage);
		}
		cvSaveImage("out_eigenfaces.bmp", bigImage);
		cvReleaseImage(&bigImage);
	}
}//storeEigenfaceImages


// Read the names & image filenames of people from a text file, and load all those images listed.
IplImage **FaceRecognitionObject::loadFaceImageArray(char *filename, int *numFaces)
{
  IplImage **faceImageArray;
	FILE * imageListFile = 0;
	char imageFilename[512];
	int iFace, nFaces=0;
	int i;

	// open the input file
	if( !(imageListFile = fopen(filename, "r")) )
	{
		fprintf(stderr, "Can\'t open file %s\n", filename);
		return 0;
	}

	// count the number of faces
	while( fgets(imageFilename, 512, imageListFile) ) ++nFaces;
	rewind(imageListFile);

	// allocate the face-image array and person number matrix
	faceImageArray = (IplImage **)cvAlloc( nFaces*sizeof(IplImage *) );
	personNumTruthMat = cvCreateMat( 1, nFaces, CV_32SC1 );

	personNames.clear();	// Make sure it starts as empty.
	nPersons = 0;

	// store the face images in an array
	for(iFace=0; iFace<nFaces; iFace++)
	{
		char personName[256];
		string sPersonName;
		int personNumber;

		// read person number (beginning with 1), their name and the image filename.
		fscanf(imageListFile, "%d %s %s", &personNumber, personName, imageFilename);
		sPersonName = personName;
		//printf("Got %d: %d, <%s>, <%s>.\n", iFace, personNumber, personName, imageFilename);

		// Check if a new person is being loaded.
		if (personNumber > nPersons) {
			// Allocate memory for the extra person (or possibly multiple), using this new person's name.
			for (i=nPersons; i < personNumber; i++) {
				personNames.push_back( sPersonName );
			}
			nPersons = personNumber;
			//printf("Got new person <%s> -> nPersons = %d [%d]\n", sPersonName.c_str(), nPersons, personNames.size());
		}

		// Keep the data
		personNumTruthMat->data.i[iFace] = personNumber;

		// load the face image
		faceImageArray[iFace] = cvLoadImage(imageFilename, CV_LOAD_IMAGE_GRAYSCALE);

		if( !faceImageArray[iFace] )
		{
			printf("Can\'t load image from %s\n", imageFilename);
			return 0;
		}
	}

	fclose(imageListFile);

	printf("Data loaded from '%s': (%d images of %d people).\n", filename, nFaces, nPersons);
	printf("People: ");
	if (nPersons > 0)
	{
		printf("<%s>", personNames[0].c_str());
	}
	for (i=1; i<nPersons; i++) 
	{
		printf(", <%s>", personNames[i].c_str());
	}
	printf(".\n");

  *numFaces = nFaces;

	return faceImageArray;
}//loadFaceImageArray


// Get an 8-bit equivalent of the 32-bit Float image.
// Returns a new image, so remember to call 'cvReleaseImage()' on the result.
IplImage* FaceRecognitionObject::convertFloatImageToUcharImage(const IplImage *srcImage)
{
	IplImage *dstImage = 0;
	if ((srcImage) && (srcImage->width > 0 && srcImage->height > 0)) {

		// Spread the 32bit floating point pixels to fit within 8bit pixel range.
		double minVal, maxVal;
		cvMinMaxLoc(srcImage, &minVal, &maxVal);

		//cout << "FloatImage:(minV=" << minVal << ", maxV=" << maxVal << ")." << endl;

		// Deal with NaN and extreme values, since the DFT seems to give some NaN results.
		if (cvIsNaN(minVal) || minVal < -1e30)
			minVal = -1e30;
		if (cvIsNaN(maxVal) || maxVal > 1e30)
			maxVal = 1e30;
		if (maxVal-minVal == 0.0f)
			maxVal = minVal + 0.001;	// remove potential divide by zero errors.

		// Convert the format
		dstImage = cvCreateImage(cvSize(srcImage->width, srcImage->height), 8, 1);
		cvConvertScale(srcImage, dstImage, 255.0 / (maxVal - minVal), - minVal * 255.0 / (maxVal-minVal));
	}
	return dstImage;
}//convertFloatImageToUcharImage



// Open the training data from the file 'facedata.xml'.
int FaceRecognitionObject::loadTrainingData(char *filename)
{
	CvFileStorage * fileStorage;
	int i;
	const char *tmpString;
	
	if (trainingFilename == 0)
	{
	  trainingFilename = (char *) malloc(sizeof(char) * 256);
	}

	// create a file-storage interface
	fileStorage = cvOpenFileStorage( filename, 0, CV_STORAGE_READ );
	if( !fileStorage ) {
		printf("Can't open training database file %s.\n",filename);
		return 0;
	}
	
	tmpString = cvReadStringByName( fileStorage, 0, "trainingFilename");
	strncpy(trainingFilename,tmpString,256);	
	
	faceWidth = cvReadIntByName(fileStorage,0,"faceWidth",0);
	faceHeight = cvReadIntByName(fileStorage,0,"faceHeight",0);

	// Load the person names.
	personNames.clear();	// Make sure it starts as empty.
	nPersons = cvReadIntByName( fileStorage, 0, "nPersons", 0 );
	if (nPersons == 0) {
		printf("No people found in the training database file %s.\n",filename);
		return 0;
	}
	
	// Load each person's name.
	for (i=0; i<nPersons; i++) {
		string sPersonName;
		char varname[200];
		sprintf( varname, "personName_%d", (i+1) );
		sPersonName = cvReadStringByName(fileStorage, 0, varname );
		personNames.push_back( sPersonName );
	}

	// Load the data
	nEigens = cvReadIntByName(fileStorage, 0, "nEigens", 0);
	nTrainFaces = cvReadIntByName(fileStorage, 0, "nTrainFaces", 0);
	trainPersonNumMat = (CvMat *)cvReadByName(fileStorage, 0, "trainPersonNumMat", 0);
	eigenValMat  = (CvMat *)cvReadByName(fileStorage, 0, "eigenValMat", 0);
	projectedTrainFaceMat = (CvMat *)cvReadByName(fileStorage, 0, "projectedTrainFaceMat", 0);
	pAvgTrainImage = (IplImage *)cvReadByName(fileStorage, 0, "avgTrainImage", 0);
	eigenVectArray = (IplImage **)cvAlloc(nTrainFaces*sizeof(IplImage *));
	for(i=0; i<nEigens; i++)
	{
		char varname[200];
		sprintf( varname, "eigenVect_%d", i );
		eigenVectArray[i] = (IplImage *)cvReadByName(fileStorage, 0, varname, 0);
	}

	// release the file-storage interface
	cvReleaseFileStorage( &fileStorage );

	printf("Training data loaded (%d training images of %d people):\n", nTrainFaces, nPersons);
	printf("People: ");
	if (nPersons > 0)
	{
		printf("<%s>", personNames[0].c_str());
	}
	
	for (i=1; i<nPersons; i++) 
	{
		printf(", <%s>", personNames[i].c_str());
	}
	printf(".\n");

  trained = true;

	return 1;
}//loadTrainingData

// Recognize the face in each of the test images given, and compare the results with the truth.
float FaceRecognitionObject::recogniseFileList(char *szFileTest)
{
  IplImage **faceImageArray; // array of face images
	int i, nTestFaces  = 0;         // the number of test images
	//CvMat * trainPersonNumMat = 0;  // the person numbers during training
	float * projectedTestFace = 0;
	char *answer = (char *) malloc(8*sizeof(char));
	int nCorrect = 0;
	int nWrong = 0;
	double timeFaceRecognizeStart;
	double tallyFaceRecognizeTime;
	float confidence;

	// load test images and ground truth for person number
	faceImageArray = loadFaceImageArray(szFileTest, &nTestFaces);
	printf("%d test faces loaded\n", nTestFaces);

	// project the test images onto the PCA subspace
	projectedTestFace = (float *)cvAlloc( nEigens*sizeof(float) );
	timeFaceRecognizeStart = (double)cvGetTickCount();	// Record the timing.
	for(i=0; i<nTestFaces; i++)
	{
		int iNearest, nearest, truth;

		// project the test image onto the PCA subspace
		cvEigenDecomposite(faceImageArray[i],nEigens,eigenVectArray,0,0,pAvgTrainImage,projectedTestFace);

		iNearest = findNearestNeighbor(projectedTestFace, &confidence);
		truth    = personNumTruthMat->data.i[i];
		nearest  = trainPersonNumMat->data.i[iNearest];

		if (nearest == truth) 
		{
			memcpy(answer,"Correct",8);
			nCorrect++;
		}
		else 
		{
			memcpy(answer,"WRONG!",8);
			nWrong++;
		}
		printf("nearest = %d, Truth = %d (%s). Confidence = %f\n", nearest, truth, answer, confidence);
		
	}
	tallyFaceRecognizeTime = (double)cvGetTickCount() - timeFaceRecognizeStart;
	if (nCorrect+nWrong > 0) 
	{
		printf("TOTAL ACCURACY: %d%% out of %d tests.\n", nCorrect * 100/(nCorrect+nWrong), (nCorrect+nWrong));
		printf("TOTAL TIME: %.1fms average.\n", tallyFaceRecognizeTime/((double)cvGetTickFrequency() * 1000.0 * (nCorrect+nWrong) ) );
	}
	
	cvReleaseImage(faceImageArray);
    
  return nCorrect * 100.0f/(nCorrect+nWrong);

}//recogniseFileList

// Find the most likely person based on a detection. Returns the index, and stores the confidence value into pConfidence.
int FaceRecognitionObject::findNearestNeighbor(float *projectedTestFace, float *pConfidence)
{
	//double leastDistSq = 1e12;
	double leastDistSq = DBL_MAX;
	int i, iTrain, iNearest = 0;

	for(iTrain=0; iTrain<nTrainFaces; iTrain++)
	{
		double distSq=0;
        
        //printf("projectedTrainFaceMat = %p, pTFM->data.fl = %f\n",projectedTrainFaceMat,projectedTrainFaceMat->data.fl[0]);
        
		for(i=0; i<nEigens; i++)
		{
		    //printf("iTrain = %d, i = %d\n",iTrain,i);
			float d_i = projectedTestFace[i] - projectedTrainFaceMat->data.fl[iTrain*nEigens + i];
#ifdef USE_MAHALANOBIS_DISTANCE
			distSq += d_i*d_i / eigenValMat->data.fl[i];  // Mahalanobis distance (might give better results than Eucalidean distance)
#else
			distSq += d_i*d_i; // Euclidean distance.
#endif
		}

		if(distSq < leastDistSq)
		{
			leastDistSq = distSq;
			iNearest = iTrain;
		}
	}

	// Return the confidence level based on the Euclidean distance,
	// so that similar images should give a confidence between 0.5 to 1.0,
	// and very different images should give a confidence between 0.0 to 0.5.
	*pConfidence = 1.0f - sqrt( leastDistSq / (float)(nTrainFaces * nEigens) ) / 255.0f;
    
	// Return the found index.
	return iNearest;
}//findNearestNeighbour

// Creates a new image copy that is of a desired size.
// Remember to free the new image later.
IplImage* FaceRecognitionObject::resizeImage(const IplImage *origImage, int newWidth, int newHeight)
{
	IplImage *outImage = 0;
	int origWidth;
	int origHeight;
	if (origImage) 
	{
		origWidth = origImage->width;
		origHeight = origImage->height;
	}
	if (newWidth <= 0 || newHeight <= 0 || origImage == 0 || origWidth <= 0 || origHeight <= 0) 
	{
		printf("ERROR in resizeImage: Bad desired image size of %dx%d\n.", newWidth, newHeight);
		exit(1);
	}
	
	//printf("Original image was w=%d,h=%d, new image is w=%d,h=%d\n",origWidth,origHeight,newWidth,newHeight);

	// Scale the image to the new dimensions, even if the aspect ratio will be changed.
	outImage = cvCreateImage(cvSize(newWidth, newHeight), origImage->depth, origImage->nChannels);
	if (newWidth > origImage->width && newHeight > origImage->height) 
	{
		// Make the image larger
		cvResetImageROI((IplImage*)origImage);
		cvResize(origImage, outImage, CV_INTER_LINEAR);	// CV_INTER_CUBIC or CV_INTER_LINEAR is good for enlarging
	}
	else 
	{
		// Make the image smaller
		cvResetImageROI((IplImage*)origImage);
		cvResize(origImage, outImage, CV_INTER_AREA);	// CV_INTER_AREA is good for shrinking / decimation, but bad at enlarging.
	}

	return outImage;
}

// Returns a new image that is a cropped version of the original image. 
IplImage* FaceRecognitionObject::cropImage(const IplImage *image, const CvRect region)
{
	IplImage *imageTmp;
	IplImage *imageRGB;
	CvSize size;
	size.height = image->height;
	size.width = image->width;

	if (image->depth != IPL_DEPTH_8U) 
	{
		printf("ERROR in cropImage: Unknown image depth of %d given in cropImage() instead of 8 bits per pixel.\n", image->depth);
		exit(1);
	}

	// First create a new (color or greyscale) IPL Image and copy contents of image into it.
	imageTmp = cvCreateImage(size, IPL_DEPTH_8U, image->nChannels);
	cvCopy(image, imageTmp, NULL);

	// Create a new image of the detected region
	// Set region of interest to that surrounding the face
	cvSetImageROI(imageTmp, region);
	// Copy region of interest (i.e. face) into a new iplImage (imageRGB) and return it
	size.width = region.width;
	size.height = region.height;
	imageRGB = cvCreateImage(size, IPL_DEPTH_8U, image->nChannels);
	cvCopy(imageTmp, imageRGB, NULL);	// Copy just the region.

  cvReleaseImage( &imageTmp );
	
	return imageRGB;		
}


// Return a new image that is always greyscale, whether the input image was RGB or Greyscale.
// Remember to free the returned image using cvReleaseImage() when finished.
IplImage* FaceRecognitionObject::convertImageToGreyscale(const IplImage *imageSrc)
{
	IplImage *imageGrey;
	// Either convert the image to greyscale, or make a copy of the existing greyscale image.
	// This is to make sure that the user can always call cvReleaseImage() on the output, whether it was greyscale or not.
	if (imageSrc->nChannels == 3) 
	{
		imageGrey = cvCreateImage( cvGetSize(imageSrc), IPL_DEPTH_8U, 1 );
		cvCvtColor( imageSrc, imageGrey, CV_BGR2GRAY );
	}
	else 
	{
		imageGrey = cvCloneImage(imageSrc);
	}
	return imageGrey;
}


// Store a greyscale floating-point CvMat image into a BMP/JPG/GIF/PNG image,
// since cvSaveImage() can only handle 8bit images (not 32bit float images).
void FaceRecognitionObject::saveFloatImage(const char *filename, const IplImage *srcImage)
{
	//cout << "Saving Float Image '" << filename << "' (" << srcImage->width << "," << srcImage->height << "). " << endl;
	printf("Saving float image %s (%d,%d).\n",filename,srcImage->width,srcImage->height);
	IplImage *byteImage = convertFloatImageToUcharImage(srcImage);
	cvSaveImage(filename, byteImage);
	cvReleaseImage(&byteImage);
}


// Perform face detection on the input image, using the given Haar cascade classifier.
// Returns a rectangle for the detected region in the given image.
CvRect FaceRecognitionObject::detectFaceInImage(const IplImage *inputImage, const CvHaarClassifierCascade* cascade )
{
	const CvSize minFeatureSize = cvSize(20, 20);
	const int flags = CV_HAAR_FIND_BIGGEST_OBJECT | CV_HAAR_DO_ROUGH_SEARCH;	// Only search for 1 face.
	const float search_scale_factor = 1.1f;
	IplImage *detectImage;
	IplImage *greyImage = 0;
	CvMemStorage* storage;
	CvRect rc;
	double t;
	CvSeq* rects;
	int i;

	storage = cvCreateMemStorage(0);
	cvClearMemStorage( storage );

	// If the image is color, use a greyscale copy of the image.
	detectImage = (IplImage*)inputImage;
	if (inputImage->nChannels > 1) 
	{
		greyImage = cvCreateImage(cvSize(inputImage->width, inputImage->height), IPL_DEPTH_8U, 1 );
		cvCvtColor( inputImage, greyImage, CV_BGR2GRAY );
		detectImage = greyImage;	// Use the greyscale version as the input.
	}

	// Detect all the faces.
	t = (double)cvGetTickCount();
	rects = cvHaarDetectObjects( detectImage, (CvHaarClassifierCascade*)cascade, storage, search_scale_factor, 3, flags, minFeatureSize );
	t = (double)cvGetTickCount() - t;
	printf("[Face Detection took %d ms and found %d objects]\n", cvRound( t/((double)cvGetTickFrequency()*1000.0) ), rects->total );

	// Get the first detected face (the biggest).
	if (rects->total > 0) 
	{
    rc = *(CvRect*)cvGetSeqElem( rects, 0 );
  }
	else
	{
		rc = cvRect(-1,-1,-1,-1);	// Couldn't find the face.
  }

	//cvReleaseHaarClassifierCascade( &cascade );
	//cvReleaseImage( &detectImage );
	if (greyImage)
	{
		cvReleaseImage( &greyImage );
	}
	cvReleaseMemStorage( &storage );

	return rc;	// Return the biggest face found, or (-1,-1,-1,-1).
}

//supply a cropped image centered on the face
char *FaceRecognitionObject::recogniseSingleFace(IplImage *candidateFace, float *returnedConfidence)
{
	int i;
	float *projectedTestFace;
	int iNearest, nearest, truth;
	IplImage *sizedImage;
	IplImage *equalizedImage;
	IplImage *processedFaceImage = 0;
	CvRect faceRect;
	IplImage *shownImage;
	char keyPressed[5];
	FILE *trainFile;
	float confidence;
	char *returnString = (char *) malloc(256 * sizeof(char));
	
  // Make sure the image is the same dimensions as the training images.
  sizedImage = resizeImage(candidateFace, faceWidth, faceHeight);
  // Give the image a standard brightness and contrast, in case it was too dark or low contrast.
  equalizedImage = cvCreateImage(cvGetSize(sizedImage), 8, 1);	// Create an empty greyscale image
  cvEqualizeHist(sizedImage, equalizedImage);
  processedFaceImage = equalizedImage;

	cvShowImage("Input", processedFaceImage);
	cvWaitKey(1000);

  // If the face rec database has been loaded, then try to recognize the person currently detected.
  if (trained) 
  {
    projectedTestFace = (float *)cvAlloc( nEigens*sizeof(float) );
	  // project the test image onto the PCA subspace
    //void cvEigenDecomposite( IplImage* obj, int nEigObjs, void* eigInput, int ioFlags, void* userData, IplImage* avg, float* coeffs );
    cvEigenDecomposite(processedFaceImage, nEigens, eigenVectArray, 0, 0, pAvgTrainImage, projectedTestFace);
	  // Check which person it is most likely to be.
	  iNearest = findNearestNeighbor(projectedTestFace, &confidence);
	  nearest  = trainPersonNumMat->data.i[iNearest];
	        
	  strncpy(returnString,personNames[nearest-1].c_str(),personNames[nearest-1].length() + 1);
    *returnedConfidence = confidence;
        
    printf("Most likely person in camera: '%s' (confidence=%f).\n", returnString, confidence);
  }//endif nEigens    
  else
  {
    printf("Not trained yet, thus fail\n");
  }

	// Free the resources used for this frame.
	cvReleaseImage( &sizedImage );
	cvReleaseImage( &equalizedImage );
	
	return returnString;
}


void FaceRecognitionObject::storeNewFace(IplImage *image, char *name)
{
  if (trainingFilename == 0)
  {
    //create new training file
    newPeopleNames.clear();
    trainingFilename = (char *) malloc(256*sizeof(char));
    strncpy(trainingFilename,defaultTrainingName,256);
  }
  
  //all ok, store new face
  char *outputBuffer = (char *) malloc(200*sizeof(char));
  IplImage *formattedImage = formatImage(image);
  int foundPerson = 0;
  FILE *trainFile;
  
  //work out if we've seen this person before
  for (int i = 0; i < personNames.size(); i++)
  {
    //int strncmp ( const char * str1, const char * str2, size_t num );
    if (strncmp(name,personNames[i].c_str(),50) == 0)
    {
      foundPerson = i;
    }
  }
  
  if (foundPerson)
  {
    //then its a person we already know
    peopleAppearances[foundPerson] = peopleAppearances[foundPerson] + 1;
    sprintf(outputBuffer, "data/%d_%s%d.jpg", foundPerson, name, peopleAppearances[foundPerson]);
  }
  else
  {
    for (int i = 0; i < newPeopleNames.size(); i++)
    {
      //int strncmp ( const char * str1, const char * str2, size_t num );
      if (strncmp(name,newPeopleNames[i].c_str(),50) == 0)
      {
        foundPerson = i;
      }
    }
    
    if (foundPerson)
    {
      //then its a new person, who we've seen but not trained on
      newPeopleAppearances[foundPerson] = newPeopleAppearances[foundPerson] + 1;
      sprintf(outputBuffer, "data/%d_%s%d.jpg", foundPerson + nPersons, name, newPeopleAppearances[foundPerson]);
      foundPerson = foundPerson + nPersons;
    }
    else
    {
      //its a completely new person
      foundPerson = nPersons + numNewPeople + 1;
      newPeopleAppearances.push_back(1);
      newPeopleNames.push_back(string(name));
      numNewPeople++;
      sprintf(outputBuffer, "data/%d_%s%d.jpg", foundPerson, name, 1);
    }//else completely new person
  }//else not already trained on that person
      
	trainFile = fopen(trainingFilename, "a");
	
	cvSaveImage(outputBuffer, formattedImage, NULL);
	fprintf(trainFile, "%d %s %s\n", foundPerson, name, outputBuffer);
	
	fclose(trainFile);
  
}//storeNewFace(IplImage *, char *)

FaceRecognitionObject *FaceRecognitionObject::retrain()
{
  if (numNewFaces == 0)
  {
    printf("ERROR: No new faces to train with\n");
    return this;
  }
  else
  {
    FaceRecognitionObject *newObj = new FaceRecognitionObject(faceWidth,faceHeight,trainingFilename);
    return newObj;
  }
}//retrain()


IplImage *FaceRecognitionObject::formatImage(IplImage *originalImage)
{
  IplImage *grayImage;
  IplImage *sizedImage;
  IplImage *equalizedImage;
  
	grayImage = convertImageToGreyscale(originalImage);
  sizedImage = resizeImage(grayImage, faceWidth, faceHeight);
  // Give the image a standard brightness and contrast, in case it was too dark or low contrast.
  equalizedImage = cvCreateImage(cvGetSize(sizedImage), 8, 1);	// Create an empty greyscale image
  cvEqualizeHist(sizedImage, equalizedImage);
    
  cvReleaseImage(&grayImage);
  cvReleaseImage(&sizedImage);
  
  return equalizedImage;
}//formatImage(IplImage *)

