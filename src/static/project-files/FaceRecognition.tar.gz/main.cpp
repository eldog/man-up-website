#include "cv.h"
#include "cvaux.h"
#include "highgui.h"
#include "FaceRecognitionObject.h"
#include "SpeechSynthObject.h"

#include <iostream>
#include <string>

CvCapture* camera = 0;	// The camera device.

// Haar Cascade file, used for Face Detection.
const char *faceCascadeFilename = "haarcascade_frontalface_alt.xml";

// Grab the next camera frame. Waits until the next frame is ready,
// and provides direct access to it, so do NOT modify the returned image or free it!
// Will automatically initialize the camera on the first frame.
IplImage* getCameraFrame(void)
{
	IplImage *frame;

	if(camera)
	{
		cvReleaseCapture( &camera );
		camera = 0;
	}

	// If the camera hasn't been initialized, then open it.
	if (!camera) {
		printf("Acessing the camera ...\n");
		camera = cvCaptureFromCAM( 0 );
		if (!camera) {
			printf("ERROR in getCameraFrame(): Couldn't access the camera.\n");
			exit(1);
		}
		// Try to set the camera resolution
		cvSetCaptureProperty( camera, CV_CAP_PROP_FRAME_WIDTH, 320 );
		cvSetCaptureProperty( camera, CV_CAP_PROP_FRAME_HEIGHT, 240 );
		// Wait a little, so that the camera can auto-adjust itself
		//sleep(1000);	// (in milliseconds)
		cvWaitKey(500);		
		frame = cvQueryFrame( camera );	// get the first frame, to make sure the camera is initialized.
		if (frame) {
			printf("Got a camera using a resolution of %dx%d.\n", (int)cvGetCaptureProperty( camera, CV_CAP_PROP_FRAME_WIDTH), (int)cvGetCaptureProperty( camera, CV_CAP_PROP_FRAME_HEIGHT) );
		}
	}
	
	//printf("Capture speed is %f\n",cvGetCaptureProperty(camera,CV_CAP_PROP_POS_MSEC));
	frame = cvQueryFrame( camera );
	if (!frame) {
		fprintf(stderr, "ERROR in recognizeFromCam(): Could not access the camera or video file.\n");
		exit(1);
		//return NULL;
	}
	return frame;
}

// Continuously recognize the person in the camera.
void recognizeFromCam(void)
{
	int i;
	int keyPressed;
	double timeFaceRecognizeStart;
	double tallyFaceRecognizeTime;
	CvHaarClassifierCascade* faceCascade;
	float *confidence = (float *) malloc(sizeof(float));
	char *recognisedPersonName;
	char *output = (char *) malloc(256*sizeof(char));

  printf("Loading in face database\n");
  FaceRecognitionObject *faceDB = new FaceRecognitionObject("facedata.xml");
  
  if (!faceDB->getTrained())
  {
      printf("ERROR, could not load face database from facedata.xml\n");
      exit(1);
  }
  
  printf("Constructing speech synthesizer\n");
  SpeechSynthObject *synth = new SpeechSynthObject();

	// Create a GUI window for the user to see the camera image.
	cvNamedWindow("Input", CV_WINDOW_AUTOSIZE);

	// Load the HaarCascade classifier for face detection.
	faceCascade = (CvHaarClassifierCascade*)cvLoad(faceCascadeFilename, 0, 0, 0 );
	if( !faceCascade ) {
		printf("ERROR in recognizeFromCam(): Could not load Haar cascade Face detection classifier in '%s'.\n", faceCascadeFilename);
		exit(1);
	}

	timeFaceRecognizeStart = (double)cvGetTickCount();	// Record the timing.

	while (1)
	{
		IplImage *camImg;
		IplImage *greyImg;
		IplImage *faceImg;
		IplImage *processedFaceImg;
		CvRect faceRect;
		IplImage *shownImg;
		//char keyPressed[2];

		printf("Recognizing person in the camera ...\n");				

		// Get the camera frame
		camImg = getCameraFrame();
		if (!camImg) 
		{
			printf("ERROR in recognizeFromCam(): Bad input image!\n");
			exit(1);
		}
		// Make sure the image is greyscale, since the Eigenfaces is only done on greyscale image.
		greyImg = FaceRecognitionObject::convertImageToGreyscale(camImg);

		// Perform face detection on the input image, using the given Haar cascade classifier.
		faceRect = FaceRecognitionObject::detectFaceInImage(greyImg, faceCascade );
		// Make sure a valid face was detected.
		
		// Show the data on the screen.
		shownImg = cvCloneImage(camImg);
		if (faceRect.width > 0) {
			faceImg = FaceRecognitionObject::cropImage(greyImg, faceRect);	// Get the detected face image.
			
			//call the object
			recognisedPersonName = faceDB->recogniseSingleFace(faceImg, confidence);
			
			// Free the resources used for this frame.
			cvReleaseImage( &faceImg );
			
			// Show the detected face region.
			cvRectangle(shownImg, cvPoint(faceRect.x, faceRect.y), cvPoint(faceRect.x + faceRect.width-1, faceRect.y + faceRect.height-1), CV_RGB(0,255,0), 1, 8, 0);
			// Check if the face recognition database is loaded and a person was recognized.
			if (faceDB->getTrained()) 
			{
				// Show the name of the recognized person, overlayed on the image below their face.
				CvFont font;
				cvInitFont(&font,CV_FONT_HERSHEY_PLAIN, 1.0, 1.0, 0,1,CV_AA);
				CvScalar textColor = CV_RGB(0,255,255);	// light blue text
				char text[256];
				snprintf(text, sizeof(text)-1, "Name: '%s'", recognisedPersonName);
				cvPutText(shownImg, text, cvPoint(faceRect.x, faceRect.y + faceRect.height + 15), &font, textColor);
				snprintf(text, sizeof(text)-1, "Confidence: %f", *confidence);
				cvPutText(shownImg, text, cvPoint(faceRect.x, faceRect.y + faceRect.height + 30), &font, textColor);
			}
						
			if (*confidence > 0.6)
			{
			  sprintf(output,"I think you are %s, with confidence %.2f\n",recognisedPersonName,*confidence);
			}
			else
			{
		    sprintf(output,"I found a face, but I don't know who it is. Scary\n");
			}
			printf("%s",output);
			synth->say(output);
			
      cvReleaseImage(&faceImg);
		}
		else
		{
			sprintf(output,"No face found. Sad panda.\n");
			printf("%s",output);
			synth->say(output);
		}
			

		// Display the image.
		cvShowImage("Input", shownImg);

		// OpenCV only draws to the screen when cvWaitKey is called.
		printf("Press a key to continue\n");
		keyPressed = cvWaitKey();
        
    cvReleaseImage(&greyImg);
		cvReleaseImage(&shownImg);
	}
	tallyFaceRecognizeTime = (double)cvGetTickCount() - timeFaceRecognizeStart;

	// Free the camera and memory resources used.
	cvReleaseCapture( &camera );
	cvReleaseHaarClassifierCascade( &faceCascade );
}


// Startup routine.
int main( int argc, char** argv )
{
	//printUsage();

	if( argc >= 2 && strcmp(argv[1], "train") == 0 ) {
		char *szFileTrain;
		if (argc == 3)
			szFileTrain = argv[2];	// use the given arg
		else 
		{
			printf("ERROR: No training file given.\n");
			return 1;
		}
		FaceRecognitionObject *newObj = new FaceRecognitionObject(92,112,szFileTrain);
	}
	else if( argc >= 2 && strcmp(argv[1], "test") == 0) {
		char *szFileTest;
		if (argc == 3)
			szFileTest = argv[2];	// use the given arg
		else {
			printf("ERROR: No testing file given.\n");
			return 1;
		}
		
		FaceRecognitionObject *newObj = new FaceRecognitionObject("facedata.xml");
		
		float accuracy = newObj->recogniseFileList(szFileTest);
		
		SpeechSynthObject *newSynth = new SpeechSynthObject();
		
		char *buffer = (char *) malloc(200*sizeof(char));
		
		sprintf(buffer,"The overall accuracy was %f",accuracy);
		
		newSynth->say(buffer);
	}
	else 
	{
		recognizeFromCam();
	}
	return 0;
}//main
