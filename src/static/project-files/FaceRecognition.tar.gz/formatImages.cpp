#include "cv.h"
#include "cvaux.h"
#include "highgui.h"
#include "FaceRecognitionObject.h"

#include <string>
#include <cstdio>

// Haar Cascade file, used for Face Detection.
const char *faceCascadeFilename = "haarcascade_frontalface_alt.xml";

int main()
{
    char personName[256];
	string sPersonName;
	int personNumber;
	char imgFilename[512];
	CvHaarClassifierCascade* faceCascade;
	char *listFilename = "formatting.txt";
	
	IplImage *faceImage;
	IplImage *currentImage;
	IplImage *equalizedImage;
	IplImage *sizedImage;
	
	
    FILE *imgListFile = fopen(listFilename, "r");
	faceCascade = (CvHaarClassifierCascade*)cvLoad(faceCascadeFilename, 0, 0, 0 );
    
	// store the face images in an array
	for(int i = 0; i<67; i++)
	{
		// read person number (beginning with 1), their name and the image filename.
		fscanf(imgListFile, "%d %s %s", &personNumber, personName, imgFilename);
		// load the face image
		currentImage = cvLoadImage(imgFilename, CV_LOAD_IMAGE_GRAYSCALE);
		// Perform face detection on the input image, using the given Haar cascade classifier.
		CvRect faceRect = FaceRecognitionObject::detectFaceInImage(currentImage, faceCascade );
		if (faceRect.width > 0)
		{
		    faceImage = FaceRecognitionObject::cropImage(currentImage, faceRect);	// Get the detected face image.
            sizedImage = FaceRecognitionObject::resizeImage(faceImage, 92, 112);
            equalizedImage = cvCreateImage(cvGetSize(sizedImage), 8, 1);	// Create an empty greyscale image
            cvEqualizeHist(sizedImage, equalizedImage);

            int length = strlen(imgFilename);
            imgFilename[length] = 'm';
            imgFilename[length] = 0;

            FaceRecognitionObject::saveFloatImage(imgFilename,equalizedImage);
        }
    }

	fclose(imgListFile);
}
