#ifndef SPEECHSYNTH_H
#define SPEECHSYNTH_H

//#include <string>
//#include <vector>
#include "espeak/speak_lib.h"

using namespace std;
//Created with help from
//http://stackoverflow.com/questions/2661129/espeak-sapi-dll-usage-on-windows

class SpeechSynthObject
{ 

    public:
        SpeechSynthObject();
        ~SpeechSynthObject();
        
        //train method
        void say(char *stringToSay);
  
  
    private:
        //private methods
        
        //private variables
        char voicename[40]; 
        int samplerate; 
        char genders[4];
        
        //private constants
        
        
}; //class SpeechSynthObject

#endif
