#ifndef FACERECOGNITION_H
#define FACERECOGNITION_H

#include <string>
#include <vector>
#include "cv.h"
#include "cvaux.h"

using namespace std;
//Created with help from
//http://www.shervinemami.co.cc/faceRecognition.html

class FaceRecognitionObject
{ 

    public:
        //constructor from training file
        FaceRecognitionObject(int newFaceWidth, int newFaceHeight, char *filename);
        //constructor from a trained output file
        FaceRecognitionObject(char *trainXMLPath);
        //blank constructor
        FaceRecognitionObject(int newFaceWidth, int newFaceHeight);
        
        //destructor
        ~FaceRecognitionObject();
        
        //accessor methods
        bool getTrained();
        int getFaceWidth();
        int getFaceHeight();
        
        //train method
        void trainFromFile(char *szFileTrain);
        
        //online train method, first store new faces, then retrain
        void storeNewFace(IplImage *image, char *name);
        FaceRecognitionObject *retrain();
        
        //save object
        void storeTrainingData();
        
        //query method
        char *recogniseSingleFace(IplImage *candidateFace, float *returnedConfidence);
        
        //query using a list of data
        float recogniseFileList(char *szFileTest);
        
        //format an image to the current standard
        IplImage *formatImage(IplImage *originalImage);
  
        //image formatting methods
        static IplImage* resizeImage(const IplImage *origImage, int newWidth, int newHeight);
        static IplImage* cropImage(const IplImage *image, const CvRect region);
        static IplImage* convertImageToGreyscale(const IplImage *imageSrc);
        static IplImage* convertFloatImageToUcharImage(const IplImage *srcImage);
        static void saveFloatImage(const char *filename, const IplImage *srcImage);
        static CvRect detectFaceInImage(const IplImage *inputImage, const CvHaarClassifierCascade* cascade );
  
    private:
        //private methods
        void storeEigenfaceImages();
        void doPCA(IplImage **faceImageArray);
        IplImage **loadFaceImageArray(char *filename, int *numFaces);
        int loadTrainingData(char *filename);
        int findNearestNeighbor(float * projectedTestFace, float *pConfidence);
            
        //private variables
        //IplImage **faceImageArray; // array of face images
        char *trainingFilename;
        int numNewFaces;
        int numNewPeople;
        vector<string> newPeopleNames;
        vector<int> newPeopleAppearances;
        CvMat    *personNumTruthMat; // array of person numbers
        vector<string> personNames;			// array of person names (indexed by the person number). Added by Shervin.
        vector<int> peopleAppearances;
        int nPersons; // the number of people in the training set. Added by Shervin.
        int nTrainFaces; // the number of training images
        int nEigens; // the number of eigenvalues
        IplImage *pAvgTrainImage; // the average image
        IplImage **eigenVectArray; // eigenvectors
        CvMat *eigenValMat; // eigenvalues
        CvMat *projectedTrainFaceMat; // projected training faces
        CvMat *trainPersonNumMat;
        int faceWidth;
        int faceHeight;

        bool trained;
        
        //constants        
        //const static int faceWidth = 92; //120
        //const static int faceHeight = 112; //90
        const static int saveEigenFaceImages = 1;
  
  
}; //class FaceRecognitionObject

#endif
