
#include <cstring>
#include <vector>
#include "espeak/speak_lib.h"
#include "SpeechSynthObject.h"

const char *data_path = "/usr/share";

SpeechSynthObject::SpeechSynthObject()
{
    genders[0] = ' ';
    genders[1] = 'M';
    genders[2] = 'F';
    genders[3] = ' ';

    const char* szVersionInfo = espeak_Info(NULL);

    printf("Espeak version: %s\n", szVersionInfo);
    samplerate = espeak_Initialize(AUDIO_OUTPUT_PLAYBACK,0,data_path,0);
    strcpy(voicename, "lancashire");
    
    if(espeak_SetVoiceByName(voicename) != EE_OK)
    {
        printf("Espeak setvoice error...\n");
    }
    
    int speed = 200;
    int volume = 500; // volume in range 0-100    0=silence
    int pitch = 55; //  base pitch, range 0-100.  50=normal
    
    espeak_SetParameter(espeakRATE, speed, 0);
    espeak_SetParameter(espeakVOLUME,volume,0);
    espeak_SetParameter(espeakPITCH,pitch,0);
        
    //espeak_VOICE *voice_spec = espeak_GetCurrentVoice();
    //voice_spec->gender=2; // 0=none 1=male, 2=female,
    //voice_spec->age = age;

    //espeak_SetVoiceByProperties(voice_spec);
}//constructor

SpeechSynthObject::~SpeechSynthObject()
{ 
    espeak_Terminate();   
}//destructor

void SpeechSynthObject::say(char *stringToSay)
{
    espeak_Synth( stringToSay, strlen(stringToSay)+1, 0, POS_CHARACTER, 0, espeakCHARS_AUTO, NULL, NULL);
    espeak_Synchronize();
}//say(char *)
